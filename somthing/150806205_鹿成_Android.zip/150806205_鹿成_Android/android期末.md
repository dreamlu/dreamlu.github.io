yummy_talk(Navication DrawerActivity的使用):

 - 视频观看
![](录制.mp4)

 - 主题
     1.帮助使用者解决一日三餐吃什么的问题，当人们面对越来越多的美食时，选择变成了难题，而通过这款APP可以用最快的时间来解决这个问题。
     
    2.帮助使用者发现自己身边的美食，改善自己的饮食。
    
	3.为美食类移动应用的发展带来一种新的思维模式与发展方向，从使用者个体的角度进行美食分享。
	

特点：
1.注册登录，toast提示

2.应用开始3秒静态图片(广告),程序入口Title_jactivity.java

3.sqllite数据库

4.UI组件的include嵌套，如app_bar_main.xml中<include layout="@layout/content_main" />

5.图片点击动态切换img.setImageDrawable()方式

6.WebView容器的使用，将网页嵌入原生app中(注：这里是美食分类网页)

7.相机拍摄图片上传的使用(有bug)

注意：此项目是Ubuntu下sudo权限启动AndroidStudio开发，建议相同配置

